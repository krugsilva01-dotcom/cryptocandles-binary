
import { MarketData } from '../types';

// CoinGecko API for simple price data
const COINGECKO_API = 'https://api.coingecko.com/api/v3';
// Binance API for candlestick data
const BINANCE_API = 'https://api.binance.com/api/v3';
// AwesomeAPI for Real-time Fiat Currency (USD-BRL)
const CURRENCY_API = 'https://economia.awesomeapi.com.br/last/USD-BRL';

export const getUsdToBrlRate = async (): Promise<number> => {
    try {
        const response = await fetch(CURRENCY_API);
        if (!response.ok) {
            throw new Error('Failed to fetch currency data');
        }
        const data = await response.json();
        // A API retorna { USDBRL: { bid: "5.43", ... } }
        // Usamos 'bid' (compra) ou 'ask' (venda). 'bid' é mais comum para referência de mercado.
        return parseFloat(data.USDBRL.bid);
    } catch (error) {
        console.warn("Currency API failed: Using fallback rate 5.85");
        return 5.85; // Fallback de segurança
    }
};

export const getMarketPrices = async (): Promise<MarketData[]> => {
    try {
        const response = await fetch(`${COINGECKO_API}/coins/markets?vs_currency=usd&ids=bitcoin,ethereum,solana,cardano&order=market_cap_desc&per_page=6&page=1&sparkline=false&price_change_percentage=24h`);
        
        if (!response.ok) {
            throw new Error('Failed to fetch market data');
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.warn("Market Data: Using fallback data due to API restrictions.");
        // Return fallback mock data in case API fails (rate limits etc)
        return [
            { id: 'bitcoin', symbol: 'btc', name: 'Bitcoin', current_price: 65432.10, price_change_percentage_24h: 2.5, image: 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png' },
            { id: 'ethereum', symbol: 'eth', name: 'Ethereum', current_price: 3456.78, price_change_percentage_24h: -1.2, image: 'https://assets.coingecko.com/coins/images/279/thumb/ethereum.png' },
            { id: 'solana', symbol: 'sol', name: 'Solana', current_price: 145.67, price_change_percentage_24h: 5.8, image: 'https://assets.coingecko.com/coins/images/4128/thumb/solana.png' },
            { id: 'cardano', symbol: 'ada', name: 'Cardano', current_price: 0.45, price_change_percentage_24h: 1.1, image: 'https://assets.coingecko.com/coins/images/975/thumb/cardano.png' },
        ];
    }
};

export interface KlineData {
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
}

// Helper para mapear símbolos da Binance para IDs da CoinGecko
const symbolToId: Record<string, string> = {
    'BTCUSDT': 'bitcoin',
    'ETHUSDT': 'ethereum',
    'SOLUSDT': 'solana',
    'ADAUSDT': 'cardano'
};

// MUDANÇA CRÍTICA: Intervalo padrão alterado para '5m' (5 minutos) para precisão em Opções Binárias
export const getBinanceKlines = async (symbol: string = 'BTCUSDT', interval: string = '5m'): Promise<KlineData[]> => {
    try {
        // Tenta buscar dados reais. 
        // Nota: Em ambientes localhost ou preview (sem backend proxy), isso geralmente falha por CORS
        const response = await fetch(`${BINANCE_API}/klines?symbol=${symbol.toUpperCase()}&interval=${interval}&limit=100`);
        
        if (!response.ok) {
            throw new Error('Failed to fetch binance data');
        }

        const data = await response.json();
        
        // Map Binance format to Lightweight Charts format
        // Binance kline format: [Open time, Open, High, Low, Close, Volume, Close time, ...]
        return data.map((d: any) => ({
            time: d[0] / 1000, // Seconds
            open: parseFloat(d[1]),
            high: parseFloat(d[2]),
            low: parseFloat(d[3]),
            close: parseFloat(d[4]),
        }));

    } catch (error) {
        console.warn("Binance API failed (likely CORS), generating mock data for chart.");
        
        // Fallback Mock Data
        const mockData: KlineData[] = [];
        const now = Math.floor(Date.now() / 1000);
        let price = symbol.toUpperCase().includes('BTC') ? 65000 : symbol.toUpperCase().includes('ETH') ? 3500 : 150;
        
        // Ajuste para simular velas de 5 minutos (300 segundos)
        const timeStep = 300; 

        for (let i = 100; i > 0; i--) {
            const time = now - (i * timeStep);
            const volatility = price * 0.005; // Menor volatilidade para timeframe curto
            const change = (Math.random() - 0.5) * volatility;
            const open = price;
            const close = price + change;
            const high = Math.max(open, close) + Math.random() * (volatility * 0.2);
            const low = Math.min(open, close) - Math.random() * (volatility * 0.2);
            
            mockData.push({
                time,
                open,
                high,
                low,
                close
            });
            
            price = close;
        }
        
        return mockData;
    }
};
