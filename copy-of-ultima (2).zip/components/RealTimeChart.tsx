
import React, { useEffect, useRef, useState } from 'react';
import { createChart, ColorType, CrosshairMode } from 'lightweight-charts';
import { getBinanceKlines, KlineData } from '../services/marketService';
import * as Lucide from 'lucide-react';

interface RealTimeChartProps {
    symbol?: string;
}

const RealTimeChart: React.FC<RealTimeChartProps> = ({ symbol = 'BTCUSDT' }) => {
    const chartContainerRef = useRef<HTMLDivElement>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPrice, setCurrentPrice] = useState<number | null>(null);
    const [priceChange, setPriceChange] = useState<number>(0);

    useEffect(() => {
        if (!chartContainerRef.current) return;

        const handleResize = () => {
            if (chart) {
                chart.applyOptions({ width: chartContainerRef.current!.clientWidth });
            }
        };

        const chart = createChart(chartContainerRef.current, {
            layout: {
                background: { 
                    type: ColorType.VerticalGradient, 
                    topColor: '#0f172a', 
                    bottomColor: '#1e293b', 
                },
                textColor: '#94a3b8',
            },
            grid: {
                vertLines: { color: '#334155', style: 2 }, 
                horzLines: { color: '#334155', style: 2 },
            },
            width: chartContainerRef.current.clientWidth,
            height: 500, 
            timeScale: {
                timeVisible: true,
                secondsVisible: true, // Habilitado segundos para precisão binária
                borderColor: '#475569',
            },
            rightPriceScale: {
                borderColor: '#475569',
            },
            crosshair: {
                mode: CrosshairMode.Normal,
            },
            watermark: {
                visible: true,
                fontSize: 80,
                horzAlign: 'center',
                vertAlign: 'center',
                color: 'rgba(255, 255, 255, 0.05)',
                text: symbol,
            },
        });

        const candlestickSeries = chart.addCandlestickSeries({
            upColor: '#22c55e', 
            downColor: '#ef4444', 
            borderVisible: false,
            wickUpColor: '#4ade80', 
            wickDownColor: '#f87171', 
        });

        const loadData = async () => {
            setIsLoading(true);
            // Mudança para intervalo de 5m (5 Minutos) para precisão de Binárias
            const data = await getBinanceKlines(symbol, '5m');
            
            // Fix type error with any cast as lightweight-charts strict typing might conflict
            candlestickSeries.setData(data as any);
            
            if(data.length > 0) {
                const lastClose = data[data.length - 1].close;
                const openPrice = data[0].open;
                setCurrentPrice(lastClose);
                setPriceChange(((lastClose - openPrice) / openPrice) * 100);
            }
            
            setIsLoading(false);
        };

        loadData();

        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
            chart.remove();
        };
    }, [symbol]);

    return (
        <div className="bg-gray-800 p-1 rounded-xl border border-gray-700 shadow-2xl overflow-hidden">
            <div className="flex justify-between items-center px-4 py-3 bg-gray-900/50 border-b border-gray-700">
                <div className="flex items-center gap-3">
                    <div className="bg-gray-700 p-2 rounded-lg">
                        <Lucide.CandlestickChart className="text-primary" size={24} />
                    </div>
                    <div>
                        <h3 className="font-bold text-xl text-white tracking-wide">{symbol}</h3>
                        <span className="text-xs text-gray-900 font-bold bg-yellow-400 px-2 py-0.5 rounded shadow-sm">M5 (5 Minutos)</span>
                    </div>
                </div>
                
                {currentPrice && (
                    <div className="text-right">
                        <div className="text-2xl font-mono font-bold text-white tracking-tight">
                            ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </div>
                        <div className={`text-sm font-bold flex items-center justify-end gap-1 ${priceChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {priceChange >= 0 ? <Lucide.TrendingUp size={14} /> : <Lucide.TrendingDown size={14} />}
                            {priceChange.toFixed(2)}%
                        </div>
                    </div>
                )}
            </div>
            
            <div className="relative w-full h-[500px]">
                {isLoading && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900 z-10">
                        <Lucide.Loader className="animate-spin text-primary h-12 w-12 mb-4" />
                        <p className="text-gray-400 text-sm animate-pulse">Carregando velas (M5)...</p>
                    </div>
                )}
                <div ref={chartContainerRef} className="w-full h-full" />
            </div>
        </div>
    );
};

export default RealTimeChart;
