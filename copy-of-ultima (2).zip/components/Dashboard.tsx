
import React, { useState, useEffect } from 'react';
import { getSignals } from '../services/api';
import { getMarketPrices, getUsdToBrlRate } from '../services/marketService';
import { generateMarketInsight } from '../services/geminiService';
import { Signal, SignalType, MarketData, User, UserRole } from '../types';
import * as Lucide from 'lucide-react';
import AdPlaceholder from './AdPlaceholder';
import RealTimeChart from './RealTimeChart';

const SignalSkeleton: React.FC = () => (
    <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 flex items-start gap-4 animate-pulse">
        <div className="flex-shrink-0">
            <div className="h-12 w-12 rounded-full bg-gray-700"></div>
        </div>
        <div className="flex-grow">
            <div className="h-4 bg-gray-700 rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-gray-700 rounded w-full"></div>
            <div className="h-3 bg-gray-700 rounded w-1/2 mt-1"></div>
        </div>
    </div>
);

const FearAndGreedGauge: React.FC = () => {
    const value = 65; 
    const rotation = (value / 100) * 180 - 90;
    let status = "Neutro";
    let colorClass = "text-yellow-400";
    if (value < 25) { status = "Medo Extremo"; colorClass = "text-red-500"; }
    else if (value < 45) { status = "Medo"; colorClass = "text-orange-400"; }
    else if (value > 55 && value < 75) { status = "Ganância"; colorClass = "text-green-400"; }
    else if (value >= 75) { status = "Ganância Extrema"; colorClass = "text-green-500"; }

    return (
        <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 h-full flex flex-col items-center justify-center relative overflow-hidden">
            <div className="absolute top-2 right-2 opacity-20">
                <Lucide.Gauge size={48} />
            </div>
            <h3 className="font-bold text-gray-300 mb-4 self-start">Sentimento do Mercado</h3>
            <div className="relative w-48 h-24 overflow-hidden mb-2">
                <div className="absolute top-0 left-0 w-full h-full bg-gray-700 rounded-t-full"></div>
                <div className="absolute top-0 left-0 w-full h-full rounded-t-full origin-bottom transition-transform duration-1000 ease-out" style={{ background: 'conic-gradient(from 180deg at 50% 100%, #ef4444 0deg, #eab308 90deg, #22c55e 180deg)', transform: 'rotate(0deg)' }}></div>
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-32 h-16 bg-gray-800 rounded-t-full"></div>
                <div className="absolute bottom-0 left-1/2 w-1 h-20 bg-white origin-bottom transform transition-transform duration-1000" style={{ transform: `translateX(-50%) rotate(${rotation}deg)` }}></div>
            </div>
            <div className="text-center z-10">
                <div className="text-3xl font-bold text-white">{value}</div>
                <div className={`text-sm font-bold uppercase tracking-wider ${colorClass}`}>{status}</div>
            </div>
        </div>
    );
};

interface DashboardProps {
    user: User | null;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const [signals, setSignals] = useState<Signal[]>([]);
  const [marketData, setMarketData] = useState<MarketData[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMoreSignals, setLoadingMoreSignals] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT');
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [tradePrice, setTradePrice] = useState<string>('');
  const [tradeAmountBrl, setTradeAmountBrl] = useState<string>('');
  const [calculatedCrypto, setCalculatedCrypto] = useState<string>('0.000000');
  const [usdRate, setUsdRate] = useState<number>(5.85);
  const [expiryTime, setExpiryTime] = useState('5m'); // Novo: Tempo de Expiração

  const isPremium = user?.role === UserRole.PREMIUM || user?.role === UserRole.ADMIN;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [signalsResponse, marketDataRes, rate] = await Promise.all([
            getSignals(1, 5),
            getMarketPrices(),
            getUsdToBrlRate()
        ]);
        setSignals(signalsResponse.data);
        setHasMore(signalsResponse.hasMore);
        setMarketData(marketDataRes);
        setUsdRate(rate);
      } catch (error) {
        console.error("Failed to fetch data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
    const interval = setInterval(() => {
        getMarketPrices().then(data => setMarketData(data));
        getUsdToBrlRate().then(rate => setUsdRate(rate));
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
      setAiInsight(null);
      setTradeAmountBrl('');
      setCalculatedCrypto('0.000000');
      if (marketData.length > 0) {
          const cleanSymbol = selectedSymbol.replace('USDT', '').toLowerCase();
          const coinData = marketData.find(c => c.symbol === cleanSymbol);
          if (coinData) {
              setTradePrice(coinData.current_price.toString());
          }
      }
  }, [selectedSymbol, marketData]);

  useEffect(() => {
      const price = parseFloat(tradePrice);
      const amountBrl = parseFloat(tradeAmountBrl);
      if (!isNaN(price) && !isNaN(amountBrl) && price > 0) {
          const amountUsd = amountBrl / usdRate;
          const cryptoQty = amountUsd / price;
          setCalculatedCrypto(cryptoQty < 1 ? cryptoQty.toFixed(6) : cryptoQty.toFixed(2));
      } else {
          setCalculatedCrypto('0.000000');
      }
  }, [tradePrice, tradeAmountBrl, usdRate]);

  const handleLoadMore = async () => {
      setLoadingMoreSignals(true);
      try {
          const nextPage = page + 1;
          const response = await getSignals(nextPage, 5);
          setSignals(prev => [...prev, ...response.data]);
          setPage(nextPage);
          setHasMore(response.hasMore);
      } catch (error) {
          console.error("Failed to load more signals", error);
      } finally {
          setLoadingMoreSignals(false);
      }
  };

  const handleGenerateInsight = async () => {
      if (!isPremium) return;
      setLoadingInsight(true);
      try {
          const cleanSymbol = selectedSymbol.replace('USDT', '').toLowerCase();
          const coinData = marketData.find(c => c.symbol === cleanSymbol) || marketData[0];
          if (coinData) {
              const insight = await generateMarketInsight(
                  selectedSymbol, 
                  coinData.current_price, 
                  coinData.price_change_percentage_24h
              );
              setAiInsight(insight);
          } else {
              setAiInsight("Dados de mercado insuficientes.");
          }
      } catch (error) {
          setAiInsight("Erro ao conectar à IA.");
      } finally {
          setLoadingInsight(false);
      }
  };

  const handleSmartTrade = (type: 'buy' | 'sell') => {
      if (!isPremium) return;
      const pair = selectedSymbol.replace('USDT', '_USDT'); 
      const url = `https://www.binance.com/en/trade/${pair}?type=spot`;
      window.open(url, '_blank');
  };

  const getBinanceSymbol = (coinSymbol: string) => {
      const map: Record<string, string> = { 'btc': 'BTCUSDT', 'eth': 'ETHUSDT', 'sol': 'SOLUSDT', 'ada': 'ADAUSDT', 'doge': 'DOGEUSDT', 'xrp': 'XRPUSDT' };
      return map[coinSymbol.toLowerCase()] || 'BTCUSDT';
  };

  const handleCoinClick = (coinSymbol: string) => {
      setSelectedSymbol(getBinanceSymbol(coinSymbol));
  };

  const baseAsset = selectedSymbol.replace('USDT', '');

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-white">Painel de Operações</h1>
        <p className="text-gray-400">Análise de Velas em Tempo Real (Opções Binárias & Spot).</p>
      </div>

      {/* Market Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {loading && marketData.length === 0 ? (
             [...Array(4)].map((_, i) => <div key={i} className="bg-gray-800 p-6 rounded-xl border border-gray-700 h-32 animate-pulse"></div>)
        ) : (
            marketData.slice(0, 4).map((coin) => (
            <div key={coin.id} onClick={() => handleCoinClick(coin.symbol)} className="group bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-lg hover:border-primary hover:shadow-primary/20 transform hover:-translate-y-1 transition-all duration-300 animate-pulse-glow-green cursor-pointer">
                <div className="flex justify-between items-start">
                <div className="flex flex-col">
                     <span className="text-gray-400 text-xs uppercase font-bold">{coin.symbol}/USD</span>
                    <p className="text-lg font-bold">{coin.name}</p>
                    <p className={`text-2xl font-semibold ${coin.price_change_percentage_24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>${coin.current_price.toLocaleString()}</p>
                </div>
                {coin.price_change_percentage_24h >= 0 ? <Lucide.ArrowUpRight className="text-success" /> : <Lucide.ArrowDownRight className="text-danger" />}
                </div>
                <p className={`text-sm font-semibold mt-2 ${coin.price_change_percentage_24h >= 0 ? 'text-success' : 'text-danger'}`}>{coin.price_change_percentage_24h >= 0 ? '+' : ''}{coin.price_change_percentage_24h.toFixed(2)}% (24h)</p>
            </div>
            ))
        )}
      </div>

      <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Terminal de Velas (M5)</h2>
            <div className="text-sm text-gray-400 bg-gray-800 px-3 py-1 rounded-full border border-gray-700">
                Câmbio: <span className="text-green-400 font-bold">USD ≈ R$ {usdRate.toFixed(2)}</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
               <div className="lg:col-span-3 space-y-4">
                   <RealTimeChart symbol={selectedSymbol} />
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* AI Scanner Panel */}
                        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 relative overflow-hidden flex flex-col">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="bg-purple-500/20 p-2 rounded-lg"><Lucide.BrainCircuit className="text-purple-400" size={24} /></div>
                                <div><h3 className="font-bold text-white">IA Sniper (Binárias)</h3><p className="text-xs text-gray-400">Análise de Probabilidade M5</p></div>
                            </div>
                            
                            {!isPremium ? (
                                <div className="flex-grow bg-gray-900/30 p-4 rounded-lg border border-gray-700 border-dashed text-center flex flex-col items-center justify-center">
                                    <Lucide.Lock className="text-gray-500 mb-2" size={24} />
                                    <p className="text-gray-400 text-sm mb-2">Recurso Premium</p>
                                    <button className="text-xs bg-purple-600 hover:bg-purple-500 text-white px-3 py-1 rounded">Liberar IA</button>
                                </div>
                            ) : aiInsight ? (
                                <div className="flex-grow bg-gray-900/50 p-4 rounded-lg border border-purple-500/30 animate-fade-in">
                                    <p className="text-gray-200 text-sm leading-relaxed italic font-medium">"{aiInsight}"</p>
                                </div>
                            ) : (
                                <div className="flex-grow bg-gray-900/30 p-4 rounded-lg border border-gray-800 text-center text-gray-500 text-sm flex items-center justify-center">Aguardando comando...</div>
                            )}
                            <button onClick={handleGenerateInsight} disabled={loadingInsight || !isPremium} className={`mt-4 w-full px-4 py-2 text-white text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg ${isPremium ? 'bg-purple-600 hover:bg-purple-500 shadow-purple-500/20' : 'bg-gray-700 cursor-not-allowed opacity-50'}`}>{loadingInsight ? <Lucide.Loader className="animate-spin" size={16} /> : <Lucide.Zap size={16} />} Gerar Sinal (M5)</button>
                        </div>

                        {/* Binary Options Trading Terminal */}
                        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 relative overflow-hidden flex flex-col">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="bg-blue-500/20 p-2 rounded-lg"><Lucide.MoveHorizontal className="text-blue-400" size={24} /></div>
                                <div><h3 className="font-bold text-white">Execução Rápida</h3><p className="text-xs text-gray-400">Painel de Operação</p></div>
                            </div>

                            <div className="relative flex-grow flex flex-col gap-3">
                                {!isPremium && <div className="absolute inset-0 bg-gray-900/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center text-center p-4 rounded-lg border border-gray-600/50"><Lucide.Lock className="text-indigo-400 mb-2" size={32} /><h4 className="text-white font-bold mb-1">Modo Operador</h4><p className="text-xs text-gray-300 mb-3">Opere CALL/PUT diretamente da análise.</p><span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider border border-indigo-500/30 px-2 py-1 rounded bg-indigo-500/10">Premium</span></div>}

                                <div className="grid grid-cols-2 gap-2">
                                    <div className="bg-gray-900 p-2 rounded border border-gray-700">
                                        <label className="text-[10px] text-blue-400 font-bold block mb-1">Entrada (R$)</label>
                                        <input type="number" value={tradeAmountBrl} onChange={(e) => setTradeAmountBrl(e.target.value)} className="w-full bg-transparent text-sm font-mono text-white focus:outline-none placeholder-gray-600" placeholder="100" disabled={!isPremium} />
                                    </div>
                                     <div className="bg-gray-900 p-2 rounded border border-gray-700">
                                        <label className="text-[10px] text-gray-400 font-bold block mb-1">Expiração</label>
                                        <select value={expiryTime} onChange={(e) => setExpiryTime(e.target.value)} className="w-full bg-transparent text-sm font-mono text-white focus:outline-none" disabled={!isPremium}>
                                            <option value="1m">M1 (1 min)</option>
                                            <option value="5m">M5 (5 min)</option>
                                            <option value="15m">M15 (15 min)</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div className="flex justify-between items-center px-1">
                                    <span className="text-[10px] text-gray-500">Volume Aprox:</span>
                                    <span className="text-xs font-mono text-gray-300">≈ {calculatedCrypto} {baseAsset}</span>
                                </div>

                                <div className="flex gap-2 mt-auto">
                                    <button onClick={() => handleSmartTrade('buy')} disabled={!isPremium} className="flex-1 bg-green-600 hover:bg-green-500 disabled:bg-gray-700 text-white py-3 rounded font-bold text-sm transition-colors flex flex-col items-center justify-center leading-none shadow-lg shadow-green-900/20 border-b-4 border-green-800 active:border-b-0 active:translate-y-1">
                                        <span className="text-lg">CALL</span>
                                        <span className="text-[10px] opacity-80">ACIMA 🟢</span>
                                    </button>
                                    <button onClick={() => handleSmartTrade('sell')} disabled={!isPremium} className="flex-1 bg-red-600 hover:bg-red-500 disabled:bg-gray-700 text-white py-3 rounded font-bold text-sm transition-colors flex flex-col items-center justify-center leading-none shadow-lg shadow-red-900/20 border-b-4 border-red-800 active:border-b-0 active:translate-y-1">
                                        <span className="text-lg">PUT</span>
                                        <span className="text-[10px] opacity-80">ABAIXO 🔴</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                   </div>
               </div>
               <div className="lg:col-span-1 flex flex-col gap-6">
                   <div className="h-64"><FearAndGreedGauge /></div>
                   <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 flex-grow flex flex-col">
                       <h3 className="font-bold mb-4 text-gray-300">Ativos Digitais</h3>
                       <div className="space-y-2 overflow-y-auto max-h-[250px] pr-1 custom-scrollbar">
                           {marketData.map(coin => {
                               const coinBinanceSymbol = getBinanceSymbol(coin.symbol);
                               const isSelected = coinBinanceSymbol === selectedSymbol;
                               return (
                               <div key={coin.id} onClick={() => handleCoinClick(coin.symbol)} className={`flex justify-between items-center p-3 rounded-lg cursor-pointer transition-all duration-200 ${isSelected ? 'bg-primary/20 border border-primary/50' : 'hover:bg-gray-700 border border-transparent'}`}>
                                   <div className="flex items-center gap-3"><img src={coin.image} alt={coin.name} className="w-8 h-8 rounded-full" /><div className="flex flex-col"><span className="uppercase font-bold text-xs">{coin.symbol}</span><span className="text-[10px] text-gray-400">{coin.name}</span></div></div>
                                   <div className={`text-xs font-bold ${coin.price_change_percentage_24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>{coin.price_change_percentage_24h > 0 ? '+' : ''}{coin.price_change_percentage_24h.toFixed(1)}%</div>
                               </div>
                           )})}
                       </div>
                   </div>
               </div>
          </div>
      </div>
      <AdPlaceholder type="banner" />
    </div>
  );
};

export default Dashboard;
