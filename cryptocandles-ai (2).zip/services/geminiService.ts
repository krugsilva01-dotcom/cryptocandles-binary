
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from '../types';

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result.split(',')[1]);
      } else {
        resolve('');
      }
    };
    reader.readAsDataURL(file);
  });
  const data = await base64EncodedDataPromise;
  return {
    inlineData: {
      data,
      mimeType: file.type,
    },
  };
};

export const analyzeChartImage = async (imageFile: File): Promise<AnalysisResult> => {
  // A chave é injetada via vite.config.ts no process.env.API_KEY
  // Se falhar, o erro será capturado no catch abaixo
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const imagePart = await fileToGenerativePart(imageFile);
    
    // Prompt Otimizado para OPÇÕES BINÁRIAS e Price Action
    const prompt = `
      Aja como um Trader Profissional de OPÇÕES BINÁRIAS e Price Action (Velas Japonesas).
      Analise este gráfico procurando por oportunidades de entrada imediata (1m a 5m).

      FOCO DA ANÁLISE:
      1. **Padrões de Vela:** Procure por Martelo, Engolfo, Doji, Estrela Cadente.
      2. **Zonas de Reação:** Identifique Suportes e Resistências fortes onde o preço deve reverter.
      3. **Decisão Binária:** O preço vai subir ou descer nos próximos minutos?

      DIRETRIZES:
      - **CALL (ALTA):** Se tocar suporte, tiver rejeição de fundo ou engolfo de alta.
      - **PUT (BAIXA):** Se tocar resistência, tiver rejeição de topo ou engolfo de baixa.
      - **AGUARDAR:** Se o mercado estiver lateral sem toques em zonas chave.

      FORMATO DO RESUMO (Insight do Coach):
      "Sinal de [CALL 🟢 / PUT 🔴]. Padrão de [NOME DO PADRÃO] identificado. Entrada ideal na taxa [PREÇO] com expiração para 5 minutos."

      Retorne APENAS o JSON.
      `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, { text: prompt }] },
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    patterns: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                    },
                    trend: { type: Type.STRING },
                    indicators: {
                        type: Type.OBJECT,
                        properties: {
                            rsi: { type: Type.STRING },
                            volume: { type: Type.STRING },
                        },
                        required: ['rsi', 'volume'],
                    },
                    recommendation: { type: Type.STRING },
                    confidenceScore: { type: Type.NUMBER },
                    summary: { type: Type.STRING },
                },
                required: ['patterns', 'trend', 'indicators', 'recommendation', 'confidenceScore', 'summary'],
            },
        },
    });

    const text = response.text;
    if (!text) {
        throw new Error("Failed to generate analysis content.");
    }
    return JSON.parse(text);

  } catch (error: any) {
    console.error("Error analyzing chart image:", error);
    throw new Error(error.message || "Falha ao analisar a imagem. Verifique sua conexão.");
  }
};

export const generateMarketInsight = async (symbol: string, price: number, change: number): Promise<string> => {
    try {
        // Inicialização dentro da função para garantir que as env vars carregaram
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        const prompt = `
            Aja como um robô de sinais para OPÇÕES BINÁRIAS (Binary Options).
            Ativo: ${symbol} | Preço: $${price} | Variação: ${change}%.
            
            Analise a probabilidade matemática para a próxima vela de 5 minutos (M5).
            
            Responda EXATAMENTE neste formato curto:
            "AÇÃO: [CALL 🟢 (ACIMA) / PUT 🔴 (ABAIXO)] | TAXA: $[Preço Atual] | EXPIRAÇÃO: M5 (5 Min) | [Motivo curto: ex: Tendência forte/Rejeição]"
            
            Se estiver incerto, diga "AÇÃO: AGUARDAR ⚪ | Sem volume".
        `;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text || "Sem análise disponível.";
    } catch (error) {
        console.error("Error generating market insight:", error);
        return "Não foi possível gerar o insight no momento. Verifique a API Key.";
    }
};
