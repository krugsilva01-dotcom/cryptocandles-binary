
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false
  },
  define: {
    // MÁGICA: Substitui process.env.API_KEY pelo valor real da Vercel durante a construção
    'process.env.API_KEY': 'import.meta.env.VITE_API_KEY'
    // REMOVIDO: 'process.env': {} -> Isso causava o erro de tela branca ao apagar o polyfill
  }
})