
# 🕯️ CryptoCandles AI - Binary Options Edition

**Domine o mercado de Opções Binárias com a precisão da Inteligência Artificial.**

O CryptoCandles AI é uma plataforma moderna que utiliza o **Google Gemini 2.5** para analisar padrões gráficos de velas (Candlesticks) em tempo real, oferecendo sinais de alta precisão para traders de Opções Binárias (M1/M5).

![CryptoCandles Preview](https://via.placeholder.com/800x400.png?text=CryptoCandles+AI+Preview)

## 🚀 Funcionalidades Principais

- **🧠 IA Sniper (M5):** Envie um print do gráfico ou use o scanner ao vivo. A IA identifica padrões (Martelo, Engolfo, Doji) e sugere **CALL** ou **PUT** com expiração recomendada.
- **📊 Terminal de Velas M5:** Gráficos em tempo real (TradingView) focados em timeframes curtos.
- **⚡ Execução Rápida:** Calcule seu investimento em Reais (R$) e abra a corretora no par exato instantaneamente.
- **👥 Comunidade Alpha:** Siga traders verificados, veja o ranking de assertividade e copie sinais.
- **🧪 Backtesting:** Teste suas estratégias com dados históricos antes de operar.

## 🛠️ Tecnologias Usadas

- **Frontend:** React, Vite, Tailwind CSS
- **Inteligência Artificial:** Google Gemini API (Models 2.5-flash)
- **Dados de Mercado:** Binance API (Proxy), CoinGecko
- **Backend/Auth:** Firebase (Auth & Firestore)
- **Gráficos:** Lightweight Charts (TradingView)

## ⚙️ Como Rodar Localmente

1. **Clone o repositório**
   ```bash
   git clone https://github.com/seu-usuario/cryptocandles-ai.git
   cd cryptocandles-ai
   ```

2. **Instale as dependências**
   ```bash
   npm install
   ```

3. **Configure as Chaves (.env)**
   Crie um arquivo `.env.local` e adicione suas chaves (Google AI e Firebase):
   ```env
   VITE_API_KEY=Sua_Chave_Gemini
   VITE_FIREBASE_API_KEY=...
   ```

4. **Rode o projeto**
   ```bash
   npm run dev
   ```

## ☁️ Como Publicar (Deploy)

Este projeto está configurado para **Vercel**.
1. Suba o código no GitHub.
2. Importe o projeto na Vercel.
3. Adicione as variáveis de ambiente nas configurações do projeto.

---
Desenvolvido com ❤️ para Traders de Elite.
