
import { mockUsers, mockSignalProviders, mockSignals, mockAdminUsers } from '../constants';
import { User, Signal, SignalProvider, UserRole, AdminUser, BacktestResult, Trade, PaginatedResponse } from '../types';
import { auth, db } from './firebaseConfig';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, collection, getDocs } from 'firebase/firestore';

// Simula a latência da rede para o modo Mock
const FAKE_DELAY = 800;
const BACKTEST_DELAY = 2000;

// --- AUTH SERVICES ---

export const login = async (email: string, password?: string): Promise<User> => {
    
    // 1. FIREBASE AUTH (Login Real)
    // Verifica se o Firebase foi inicializado corretamente (tem chaves)
    if (auth && db && password) {
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const firebaseUser = userCredential.user;
            
            // Buscar dados adicionais do perfil no Firestore
            const userDocRef = doc(db, 'users', firebaseUser.uid);
            const userDoc = await getDoc(userDocRef);
            
            if (userDoc.exists()) {
                const userData = userDoc.data();
                return {
                    id: firebaseUser.uid,
                    name: userData.name || firebaseUser.displayName || 'Usuário',
                    email: firebaseUser.email || email,
                    role: userData.role || UserRole.FREE,
                    plan: userData.plan || 'Gratuito'
                };
            } else {
                // Se o usuário existe no Auth mas não tem doc (caso raro), cria um básico
                return {
                    id: firebaseUser.uid,
                    name: firebaseUser.displayName || 'Usuário',
                    email: firebaseUser.email || email,
                    role: UserRole.FREE,
                    plan: 'Gratuito'
                };
            }
        } catch (error: any) {
            console.error("Erro no Login Firebase:", error);
            if (error.code === 'auth/invalid-credential' || error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password') {
                 throw new Error("Credenciais inválidas.");
            }
            // Se houver erro de rede, o sistema pode tentar cair no mock abaixo como fallback para desenvolvimento,
            // mas em produção idealmente mostraria erro.
        }
    }

    // 2. FALLBACK MOCK (Modo Demonstração ou Admin Local)
    // Se o Firebase falhar ou não estiver configurado, usamos o mock local.
    // Isso permite login com 'admkrug' (sem senha hardcoded aqui, validamos apenas existência no mock)
    
    console.warn("Tentando login MOCK (Firebase não configurado ou indisponível).");
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // Procura no array de mocks.
            // Para 'admkrug', como não temos senha no mock, aceitamos qualquer senha no modo dev.
            const user = mockUsers.find(u => u.email === email);
            
            if (user) {
                resolve(user);
            } else if (email.includes('@')) {
                // Permite entrar como convidado se parecer um email válido no modo mock e não for um usuário registrado
                const guestUser: User = { id: 'guest', name: 'Usuário Convidado', email, role: UserRole.FREE, plan: 'Gratuito' };
                resolve(guestUser);
            } else {
                reject(new Error("Usuário não encontrado (Mock)."));
            }
        }, FAKE_DELAY);
    });
};

export const register = async (email: string, password: string, name: string): Promise<User> => {
    
    // 1. FIREBASE REGISTER (Registro Real)
    if (auth && db) {
        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const firebaseUser = userCredential.user;

            const newUser: User = {
                id: firebaseUser.uid,
                name: name,
                email: email,
                role: UserRole.FREE,
                plan: 'Gratuito'
            };

            // Salvar perfil no Firestore
            await setDoc(doc(db, 'users', firebaseUser.uid), {
                name: name,
                email: email,
                role: 'free',
                plan: 'Gratuito',
                createdAt: new Date().toISOString()
            });

            return newUser;
        } catch (error: any) {
            console.error("Erro no Registro Firebase:", error);
            throw new Error(error.message || "Falha ao criar conta.");
        }
    }

    // 2. FALLBACK MOCK
    return new Promise((resolve) => {
        setTimeout(() => {
            const newUser: User = {
                id: `new_${Date.now()}`,
                name: name,
                email: email,
                role: UserRole.FREE,
                plan: 'Gratuito'
            };
            mockUsers.push(newUser);
            mockAdminUsers.unshift({
                id: newUser.id,
                name: newUser.name,
                email: newUser.email,
                plan: 'Gratuito',
                status: 'Ativo',
                joinedAt: new Date().toISOString().split('T')[0]
            });
            resolve(newUser);
        }, FAKE_DELAY);
    });
};

export const logout = async (): Promise<void> => {
    if (auth) {
        await signOut(auth);
    }
};

export const recoverPassword = async (email: string): Promise<void> => {
    console.log("Recuperação de senha solicitada para:", email);
    // Se estivesse usando firebase completo: await sendPasswordResetEmail(auth, email);
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve();
        }, FAKE_DELAY);
    });
};

// --- DATA FETCHING SERVICES ---

export const getSignals = async (page: number = 1, limit: number = 10): Promise<PaginatedResponse<Signal>> => {
    // Tentar buscar do Firestore se disponível
    if (db) {
        try {
            const signalsCol = collection(db, 'signals');
            const snapshot = await getDocs(signalsCol);
            if (!snapshot.empty) {
                const realSignals = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Signal));
                const startIndex = (page - 1) * limit;
                const endIndex = startIndex + limit;
                return {
                    data: realSignals.slice(startIndex, endIndex),
                    total: realSignals.length,
                    page,
                    limit,
                    hasMore: endIndex < realSignals.length
                };
            }
        } catch (e) {
            console.warn("Erro ao buscar sinais do Firestore, usando Mock.", e);
        }
    }

    // Fallback Mock
    return new Promise((resolve) => {
        setTimeout(() => {
            const startIndex = (page - 1) * limit;
            const endIndex = startIndex + limit;
            const paginatedSignals = mockSignals.slice(startIndex, endIndex);
            const hasMore = endIndex < mockSignals.length;

            resolve({
                data: paginatedSignals,
                total: mockSignals.length,
                page,
                limit,
                hasMore
            });
        }, FAKE_DELAY);
    });
};

export const getSignalProviders = async (): Promise<SignalProvider[]> => {
    return new Promise((resolve) => setTimeout(() => resolve(mockSignalProviders), FAKE_DELAY));
};

export const getAdminUsers = async (): Promise<AdminUser[]> => {
    return new Promise((resolve) => setTimeout(() => resolve([...mockAdminUsers]), FAKE_DELAY));
};

// --- ACTION SERVICES ---

export const runBacktest = (): Promise<BacktestResult> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const totalTrades = Math.floor(Math.random() * 50) + 20; // Menos trades, mais foco
            const winRate = Math.floor(Math.random() * 30) + 60; // Winrate realista para binárias
            const trades: Trade[] = [];

            // Gerar trades intraday (M5)
            const basePrice = 65000;
            let currentPrice = basePrice;

            for (let i = 0; i < 10; i++) {
                const isWin = Math.random() * 100 < winRate;
                const volatility = Math.random() * 50 + 10;
                
                // Hora simulada: começa às 10:00 e avança de 5 em 5 minutos
                const hour = 10 + Math.floor((i * 5) / 60);
                const minute = (i * 5) % 60;
                const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;

                currentPrice += (Math.random() - 0.5) * 100;
                const entryPrice = currentPrice;
                const type = Math.random() > 0.5 ? 'Compra' : 'Venda';
                
                // Em binárias, o resultado é fixo (ex: 85% payout ou -100% loss)
                // Aqui simulamos como percentual de retorno sobre a banca
                const result = isWin ? 85 : -100; 
                
                // Preço de saída apenas para referência visual
                const exitPrice = isWin 
                    ? (type === 'Compra' ? entryPrice + volatility : entryPrice - volatility)
                    : (type === 'Compra' ? entryPrice - volatility : entryPrice + volatility);

                trades.push({
                    date: timeString, // Exibe Horário em vez de Data
                    type,
                    entryPrice,
                    exitPrice,
                    result, // Payout ou Loss
                });
            }

            resolve({
                totalTrades,
                winRate,
                cumulativeReturn: Math.random() * 150 + 20, // Retorno agressivo de binárias
                maxDrawdown: -(Math.random() * 20 + 10),
                trades: trades.reverse(), // Mais recentes primeiro
            });
        }, BACKTEST_DELAY);
    });
};

export const upgradePlan = async (userId: string): Promise<User> => {
    // 1. ATUALIZAÇÃO NO FIREBASE
    if (db && userId !== 'admin_master' && userId !== 'guest' && !userId.startsWith('new_')) {
        try {
            const userRef = doc(db, 'users', userId);
            await updateDoc(userRef, {
                role: 'premium',
                plan: 'Premium'
            });
            
            const userSnap = await getDoc(userRef);
            const userData = userSnap.data();
            return {
                id: userId,
                name: userData?.name || 'Usuário',
                email: userData?.email || '',
                role: UserRole.PREMIUM,
                plan: 'Premium'
            };
        } catch (error) {
            console.error("Erro ao atualizar plano no Firestore", error);
        }
    }

    // 2. FALLBACK MOCK
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const userIndex = mockUsers.findIndex(u => u.id === userId);
            if (userIndex !== -1) {
                const updatedUser = {
                    ...mockUsers[userIndex],
                    role: UserRole.PREMIUM,
                    plan: 'Premium',
                };
                // Atualiza o mock em memória
                mockUsers[userIndex] = updatedUser; 
                resolve(updatedUser);
            } else {
                // Permite upgrade simulado para admin e guest
                if (userId === 'guest' || userId === 'admin_master') {
                     const updatedUser: User = { 
                         id: userId, 
                         name: userId === 'admin_master' ? 'Admin Krug' : 'Usuário Convidado', 
                         email: userId === 'admin_master' ? 'admkrug' : 'guest@test.com', 
                         role: UserRole.PREMIUM, 
                         plan: 'Premium' 
                     };
                     resolve(updatedUser);
                } else {
                    reject(new Error("User not found"));
                }
            }
        }, FAKE_DELAY);
    });
};

export const toggleFollowProvider = (providerId: string): Promise<{ success: true }> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({ success: true });
        }, FAKE_DELAY / 2);
    });
};

// --- ADMIN SERVICES ---

export const updateUserStatus = async (userId: string, newStatus: 'Ativo' | 'Suspenso'): Promise<void> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const userIndex = mockAdminUsers.findIndex(u => u.id === userId);
            if (userIndex !== -1) {
                mockAdminUsers[userIndex].status = newStatus;
            }
            resolve();
        }, FAKE_DELAY / 2);
    });
};

export const deleteUser = async (userId: string): Promise<void> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const userIndex = mockAdminUsers.findIndex(u => u.id === userId);
            if (userIndex !== -1) {
                mockAdminUsers.splice(userIndex, 1);
            }
            resolve();
        }, FAKE_DELAY / 2);
    });
};
